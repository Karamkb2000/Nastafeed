package com.example.my_first_application;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Second_layout2 extends AppCompatActivity
{
    Button search;
    Button give;
    Button booked;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        //System.out.println(MainActivity.USERNAME);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_layout2);

        booked= findViewById(R.id.booked);
        search = findViewById(R.id.search);
        give = findViewById(R.id.give);
        booked.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent1= new Intent(getApplicationContext(),Booked.class);
                startActivity(intent1);
            }
        });
        search.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                OpenSearch_layout();
            }
        });
        give.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                OpenGiveaway_layout();
            }
        });
    }
    public void  OpenSearch_layout()
    {
        Intent intent = new Intent(this, Search_layout.class);
        startActivity(intent);
    }
    public void  OpenGiveaway_layout()
    {
        Intent intent = new Intent(this, Giveaway_layout.class);
        startActivity(intent);
    }
}