package com.example.my_first_application;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{
    EditText username,password;
    Button sign,login1;
    DBhelper DB;

    static String USERNAME="";
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username=findViewById(R.id.username1);
        password=findViewById(R.id.password1);
        sign=findViewById(R.id.signin1);
        login1 =findViewById(R.id.login);
        DB = new DBhelper(this);
        login1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Intent intent= new Intent(getApplicationContext(),SingUp_layout.class);
                startActivity(intent);
            }
        });
        sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                String user=username.getText().toString();
                String pass=password.getText().toString();

                if(TextUtils.isEmpty(user)|| TextUtils.isEmpty(pass))
                    Toast.makeText(MainActivity.this,"All fields Required",Toast.LENGTH_SHORT).show();
                else
                {
                    Boolean checkuserpass = DB.checkusernamepassword(user,pass);
                    if(checkuserpass==true)
                    {
                        Toast.makeText(MainActivity.this,"Login Successful",Toast.LENGTH_SHORT).show();
                        MainActivity.USERNAME=user;
                        Intent intent= new Intent(getApplicationContext(),Second_layout2.class);
                        startActivity(intent);
                    }else
                    {
                        Toast.makeText(MainActivity.this,"Login failed",Toast.LENGTH_SHORT).show();
                    }
                }
            }

        });

    }
}