package com.example.my_first_application;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

public class Giveaway_layout extends AppCompatActivity
{
    String[] items = {"Yarmouk University","Jordanian University"};
    String[] items1 = {"Information technology and computer science","Engineering"};
    String[] items2 = {"Computer Science","computer engineer"};
    String[] items3 = {"CS411","CS281"};


    Button save;
    DBhelper DB;
    String item="";
    String item1="";
    String item2="";
    String item3="";

    AutoCompleteTextView autoCompleteTxt;
    AutoCompleteTextView autoCompleteTxt1;
    AutoCompleteTextView autoCompleteTxt2;
    AutoCompleteTextView autoCompleteTxt3;


    ArrayAdapter <String> adapterItems;
    ArrayAdapter <String> adapterItems1;
    ArrayAdapter <String> adapterItems2;
    ArrayAdapter <String> adapterItems3;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_giveaway_layout);

        autoCompleteTxt =findViewById(R.id.autoComplete_text);
        adapterItems = new ArrayAdapter<String>(this,R.layout.list_univarsety,items);
        autoCompleteTxt.setAdapter(adapterItems);

        autoCompleteTxt1 =findViewById(R.id.autoComplete_text1);
        adapterItems1 = new ArrayAdapter<String>(this,R.layout.list_univarsety,items1);
        autoCompleteTxt1.setAdapter(adapterItems1);

        autoCompleteTxt2 =findViewById(R.id.autoComplete_text2);
        adapterItems2 = new ArrayAdapter<String>(this,R.layout.list_univarsety,items2);
        autoCompleteTxt2.setAdapter(adapterItems2);

        autoCompleteTxt3 =findViewById(R.id.autoComplete_text3);
        adapterItems3 = new ArrayAdapter<String>(this,R.layout.list_univarsety,items3);
        autoCompleteTxt3.setAdapter(adapterItems3);



        save =findViewById(R.id.save);
        DB = new DBhelper(this);
        save.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if(item.isEmpty() || item1.isEmpty() || item2.isEmpty() || item3.isEmpty() )
                {
                    Toast.makeText(getApplicationContext(), "All failed are required", Toast.LENGTH_SHORT).show();
                }else
                {
                        Boolean insert1 = DB.insertData1(item,item1,item2,item3);
                        if(insert1==true)
                        {
                            Toast.makeText(Giveaway_layout.this,"All data have been saved",Toast.LENGTH_SHORT).show();
                            Intent intent1= new Intent(getApplicationContext(),Second_layout2.class);
                            startActivity(intent1);
                        }
                }


            }
        });

        autoCompleteTxt.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {

                item = parent.getItemAtPosition(position).toString();
                Toast.makeText(getApplicationContext(), "You select :" + item, Toast.LENGTH_SHORT).show();

            }

        });

        autoCompleteTxt1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                item1= parent.getItemAtPosition(position).toString();
                Toast.makeText(getApplicationContext(),"You select :"+item1,Toast.LENGTH_SHORT).show();
            }
        });

        autoCompleteTxt2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
              item2= parent.getItemAtPosition(position).toString();
              Toast.makeText(getApplicationContext(),"You select :"+item2,Toast.LENGTH_SHORT).show();
            }
        });

        autoCompleteTxt3.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                item3= parent.getItemAtPosition(position).toString();
                Toast.makeText(getApplicationContext(),"You select :"+item3,Toast.LENGTH_SHORT).show();
            }
        });


    }
}