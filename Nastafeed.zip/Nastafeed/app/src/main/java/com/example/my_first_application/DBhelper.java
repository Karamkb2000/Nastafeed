package com.example.my_first_application;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class DBhelper extends SQLiteOpenHelper
{
    public static final String DBNAME="login5.db";

    public DBhelper(Context context)
    {
        super(context, "login5.db", null, 1);
    }


    @Override
    public void onCreate(SQLiteDatabase db)
    {
      db.execSQL("create table users(username TEXT primary key ,password TEXT, phoneNumber TEXT)");
      db.execSQL("create table books(username TEXT,university TEXT, faculty TEXT,Major TEXT, course TEXT, givenTo TEXT, phone TEXT, primary key (username, course) )");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
      db.execSQL("drop table if exists users");
      //db.execSQL("drop table if exists books");
    }
    public boolean insertData(String username,String password, String phoneNumber)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("username",username);
        values.put("password",password);
        values.put("phoneNumber",phoneNumber);
        long result = db.insert("users",null,values);
        if(result==-1)return false;
        else
            return true;

    }
    public boolean insertData1(String university,String faculty,String Major,String course)
    {
        SQLiteDatabase DB=this.getWritableDatabase();
        ContentValues contentvalues = new ContentValues();

        contentvalues.put("username",MainActivity.USERNAME);
        contentvalues.put("university",university);
        contentvalues.put("faculty",faculty);
        contentvalues.put("Major",Major);
        contentvalues.put("course",course);
        contentvalues.put("givenTo","");
        contentvalues.put("phone","");

        long result = DB.insert("books",null,contentvalues);
        if(result==-1)return false;
        else
            return true;

    }
    public Cursor getedata()
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("select * from books",null);
        return  cursor;
    }
    public boolean checkusername(String username) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from users where username=?", new String[]{username});

         if(cursor.getCount()>0)
             return true;
         else
             return false;

    }
    public void updateBook(String name,String course)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv=new ContentValues();

        cv.put("givenTo",MainActivity.USERNAME);
        String phone=getPhone(MainActivity.USERNAME);
        cv.put("phone",phone);
        db.update("books",cv,"username=? and course=?",new  String[]{name,course});

    }

    public boolean checkusernamepassword(String username,String password)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from users where username=? and password=?", new String[]{username,password});

        if(cursor.getCount()>0)
            return true;
        else
            return false;
    }
    public String getPhone(String username)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c = db.rawQuery("select phoneNumber from users where username=?", new String[]{username});
        String phone="";
        if(c.moveToFirst()){
            c.moveToPosition(0);
            phone=c.getString(0);
        }
        return phone;
    }

    public Cursor getBookOptions(String uni, String faculty, String major, String course)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        String givenTo="";
        Cursor cursor = db.rawQuery("select * from books where university=? and faculty=? and Major=? and course=? and givenTo=?", new String[]{uni,faculty,major,course,givenTo});

        return cursor;
    }

    @SuppressLint("Range")
    public String getTableAsString(String tableName) {
        SQLiteDatabase db = this.getWritableDatabase();
        String tableString = String.format("Table %s:\n", tableName);
        Cursor allRows  = db.rawQuery("select course, phone from books where givenTo=?", new String[]{MainActivity.USERNAME});
        if (allRows.moveToFirst() ){
            String[] columnNames = allRows.getColumnNames();
            do {
                for (String name: columnNames) {
                    tableString += String.format("%s: %s\n", name,
                            allRows.getString(allRows.getColumnIndex(name)));
                }
                tableString += "\n";

            } while (allRows.moveToNext());
        }

        return tableString;
    }
}











