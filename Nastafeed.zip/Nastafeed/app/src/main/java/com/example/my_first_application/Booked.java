package com.example.my_first_application;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ScrollView;
import android.widget.Scroller;
import android.widget.TextView;

public class Booked extends AppCompatActivity
{
    TextView test;
    DBhelper DB;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booked);

        test= findViewById(R.id.test);
        DB = new DBhelper(this);
        test.append(DB.getTableAsString("books"));



    }
}