package com.example.my_first_application;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.Toast;

import java.util.Arrays;

public class Search_layout extends AppCompatActivity
{
    DBhelper DB;
    String[] items = {"Yarmouk University","Jordanian University"};
    String[] items1 = {"Information technology and computer science","Engineering"};
    String[] items2 = {"Computer Science","computer engineer"};
    String[] items3 = {"CS411","CS281"};
    String[] items4 = {"Option1","Option2","Option3","Option4","Option5","Option6","Option6","Option6","Option7","Option8","Option9", "Option10"};
    String[] items5 = {""};
    int index;
    String item="";
    String item1="";
    String item2="";
    String item3="";
    String item4="";
    Cursor cursor;
    Button search;
    Button book;

    AutoCompleteTextView autoCompleteTxt;
    AutoCompleteTextView autoCompleteTxt1;
    AutoCompleteTextView autoCompleteTxt2;
    AutoCompleteTextView autoCompleteTxt3;
    AutoCompleteTextView autoCompleteTxt4;

    ArrayAdapter<String> adapterItems;
    ArrayAdapter<String> adapterItems1;
    ArrayAdapter<String> adapterItems2;
    ArrayAdapter<String> adapterItems3;
    ArrayAdapter<String> adapterItems4;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        DB = new DBhelper(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_layout);

        autoCompleteTxt =findViewById(R.id.autoComplete_text);
        adapterItems = new ArrayAdapter<String>(this,R.layout.list_univarsety,items);
        autoCompleteTxt.setAdapter(adapterItems);

        autoCompleteTxt1 =findViewById(R.id.autoComplete_text1);
        adapterItems1 = new ArrayAdapter<String>(this,R.layout.list_univarsety,items1);
        autoCompleteTxt1.setAdapter(adapterItems1);

        autoCompleteTxt2 =findViewById(R.id.autoComplete_text2);
        adapterItems2 = new ArrayAdapter<String>(this,R.layout.list_univarsety,items2);
        autoCompleteTxt2.setAdapter(adapterItems2);

        autoCompleteTxt3 =findViewById(R.id.autoComplete_text3);
        adapterItems3 = new ArrayAdapter<String>(this,R.layout.list_univarsety,items3);
        autoCompleteTxt3.setAdapter(adapterItems3);

        autoCompleteTxt4 =findViewById(R.id.autoComplete_text4);
        adapterItems4 = new ArrayAdapter<String>(this,R.layout.list_univarsety,items5);
        autoCompleteTxt4.setAdapter(adapterItems4);

        search =findViewById(R.id.search1);
        book = findViewById(R.id.book);
        search.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if (item.isEmpty() || item1.isEmpty() || item2.isEmpty() || item3.isEmpty() )
                {
                    Toast.makeText(getApplicationContext(), "All failed are required", Toast.LENGTH_SHORT).show();
                }
                else{
                    cursor =DB.getBookOptions(item,item1,item2,item3);
                    if(cursor.getCount()>0) {
                        String[] options= Arrays.copyOfRange(items4,0,cursor.getCount());
                        autoCompleteTxt4 =findViewById(R.id.autoComplete_text4);
                        adapterItems4 = new ArrayAdapter<String>(Search_layout.this,R.layout.list_univarsety,options);
                        autoCompleteTxt4.setAdapter(adapterItems4);

                    }
                    else{
                        Toast.makeText(getApplicationContext(), "There is no available resources for this course.", Toast.LENGTH_SHORT).show();
                    }

                }

            }
        });
        book.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if(item4.isEmpty())
                {
                    Toast.makeText(getApplicationContext(), "No Option selected", Toast.LENGTH_SHORT).show();
                }else
                {
                    if(cursor.moveToFirst())
                    {
                        cursor.moveToPosition(index);
                        String username=cursor.getString(0);
                        String course=cursor.getString(4);
                        DB.updateBook(username,course);
                        Toast.makeText(getApplicationContext(), "You have booked this course resource.", Toast.LENGTH_SHORT).show();
                        cursor =DB.getBookOptions(item,item1,item2,item3);
                        System.out.println(cursor.getCount());
                        Intent intent1= new Intent(getApplicationContext(),Second_layout2.class);
                        startActivity(intent1);
                    }

                }
            }
        });
        autoCompleteTxt.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                item= parent.getItemAtPosition(position).toString();
                Toast.makeText(getApplicationContext(),"You select :"+item,Toast.LENGTH_SHORT).show();
            }
        });
        autoCompleteTxt1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                item1= parent.getItemAtPosition(position).toString();
                Toast.makeText(getApplicationContext(),"You select :"+item1,Toast.LENGTH_SHORT).show();
            }
        });
        autoCompleteTxt2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                item2= parent.getItemAtPosition(position).toString();
                Toast.makeText(getApplicationContext(),"You select :"+item2,Toast.LENGTH_SHORT).show();
            }
        });
        autoCompleteTxt3.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                item3= parent.getItemAtPosition(position).toString();
                Toast.makeText(getApplicationContext(),"You select :"+item3,Toast.LENGTH_SHORT).show();
            }
        });
        autoCompleteTxt4.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                index = position;
                item4= parent.getItemAtPosition(position).toString();
                Toast.makeText(getApplicationContext(),"You select :"+item4,Toast.LENGTH_SHORT).show();
            }
        });
    }
}