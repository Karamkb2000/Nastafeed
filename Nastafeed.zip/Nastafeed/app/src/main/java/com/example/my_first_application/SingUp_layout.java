package com.example.my_first_application;

        import androidx.appcompat.app.AppCompatActivity;
        import android.content.Intent;
        import android.os.Bundle;
        import android.text.TextUtils;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.Toast;

public class SingUp_layout extends AppCompatActivity
{

    EditText username,password,repassword,phone_number,email_1,fullname;
    Button signup;
    DBhelper DB;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sing_up_layout);
        username = findViewById(R.id.username);
        repassword = findViewById(R.id.repassword);
        password = findViewById(R.id.password);
        signup = findViewById(R.id.signup);
        fullname = findViewById(R.id.fullname);
        phone_number = findViewById(R.id.phone);
        email_1 = findViewById(R.id.email);
        DB=new DBhelper(this);
        signup.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {

                String user = username.getText().toString();
                String pass = password.getText().toString();
                System.out.println("string");
                String phone = phone_number.getText().toString();
                String email = email_1.getText().toString();
                String name = fullname.getText().toString();
                String repass = repassword.getText().toString();

                if (TextUtils.isEmpty(user) || TextUtils.isEmpty(pass) || TextUtils.isEmpty(repass)|| TextUtils.isEmpty(phone)|| TextUtils.isEmpty(email)|| TextUtils.isEmpty(name))
                {
                    Toast.makeText(SingUp_layout.this, "All fields Required", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    if(pass.equals(repass))
                    {
                        boolean checkuser= DB.checkusername(user);
                        if(checkuser==false)
                        {
                            Boolean insert = DB.insertData(user,pass,phone);
                            if(insert==true)
                            {
                                Toast.makeText(SingUp_layout.this,"Registered Successfully",Toast.LENGTH_SHORT).show();
                                Intent intent1= new Intent(getApplicationContext(),MainActivity.class);
                                startActivity(intent1);
                            }else
                            {
                                Toast.makeText(SingUp_layout.this,"Registration Failed",Toast.LENGTH_SHORT).show();
                            }
                        }else
                        {
                            Toast.makeText(SingUp_layout.this,"User already Exists",Toast.LENGTH_SHORT).show();
                        }

                    }else
                    {
                        Toast.makeText(SingUp_layout.this,"Password are not matching",Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });
    }

}